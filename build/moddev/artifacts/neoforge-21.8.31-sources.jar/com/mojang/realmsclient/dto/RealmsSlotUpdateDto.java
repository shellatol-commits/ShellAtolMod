package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import javax.annotation.Nullable;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class RealmsSlotUpdateDto implements ReflectionBasedSerialization {
    @SerializedName("slotId")
    public final int slotId;
    @SerializedName("pvp")
    private final boolean pvp;
    @SerializedName("spawnMonsters")
    private final boolean spawnMonsters;
    @SerializedName("spawnProtection")
    private final int spawnProtection;
    @SerializedName("commandBlocks")
    private final boolean commandBlocks;
    @SerializedName("forceGameMode")
    private final boolean forceGameMode;
    @SerializedName("difficulty")
    private final int difficulty;
    @SerializedName("gameMode")
    private final int gameMode;
    @SerializedName("slotName")
    private final String slotName;
    @SerializedName("version")
    private final String version;
    @SerializedName("compatibility")
    private final RealmsServer.Compatibility compatibility;
    @SerializedName("worldTemplateId")
    private final long templateId;
    @Nullable
    @SerializedName("worldTemplateImage")
    private final String templateImage;
    @SerializedName("hardcore")
    private final boolean hardcore;

    public RealmsSlotUpdateDto(int p_419486_, RealmsWorldOptions p_419985_, boolean p_419522_) {
        this.slotId = p_419486_;
        this.pvp = p_419985_.pvp;
        this.spawnMonsters = p_419985_.spawnMonsters;
        this.spawnProtection = p_419985_.spawnProtection;
        this.commandBlocks = p_419985_.commandBlocks;
        this.forceGameMode = p_419985_.forceGameMode;
        this.difficulty = p_419985_.difficulty;
        this.gameMode = p_419985_.gameMode;
        this.slotName = p_419985_.getSlotName(p_419486_);
        this.version = p_419985_.version;
        this.compatibility = p_419985_.compatibility;
        this.templateId = p_419985_.templateId;
        this.templateImage = p_419985_.templateImage;
        this.hardcore = p_419522_;
    }
}
